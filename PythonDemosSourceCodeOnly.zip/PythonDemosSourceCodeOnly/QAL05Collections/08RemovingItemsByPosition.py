cheese = ('Cheddar')
saved = cheese.pop(1)
print("Saved1:", saved,", Result:", cheese)

saved = cheese.pop() #Stack - LIFO
print("Saved2:", saved,", Result:", cheese)
pass