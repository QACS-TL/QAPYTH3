import demo_profiling_after_06

demo_profiling_after_06.main()

