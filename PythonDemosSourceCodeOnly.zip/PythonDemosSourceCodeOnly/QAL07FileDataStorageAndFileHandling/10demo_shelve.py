import pickle
import gzip

caps = {'Australia':'Canberra', 'Eire':'Dublin',
        'UK':'London', 'US':'Washington'}

f_outp = gzip.open('11capitals.pgz', 'wb')
pickle.dump(caps, f_outp)
f_outp.close()


f_inp = gzip.open('11capitals.pgz', 'rb')
caps = pickle.load(f_inp)
f_inp.close()

print(caps)
