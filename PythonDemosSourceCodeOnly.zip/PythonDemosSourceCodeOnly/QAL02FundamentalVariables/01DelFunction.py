my_var = 10
print(my_var)

del my_var

print(my_var)
