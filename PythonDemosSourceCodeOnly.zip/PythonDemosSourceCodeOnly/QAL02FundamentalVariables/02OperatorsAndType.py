# Note lines 4 and 9 are identical but are they doing the same thing?
a = 42
b = 9
print(a + b)
print(type(a))

a = 'Hello '
b = 'World!'
print(a + b)
print(type(a))