lang = ['Perl', 'Python', 'PHP', 'Ruby']
if 'Python' in lang:
    print('Python is there')

