num = 42
txt = '3'

if txt < num:  # syntax error
    print('Wow!')
else:
    print('Doh!')

if int(txt) < num:
    print('Wow!')
else:
    print('Doh!')
