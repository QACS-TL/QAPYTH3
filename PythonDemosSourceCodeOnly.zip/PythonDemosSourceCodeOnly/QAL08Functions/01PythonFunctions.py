def make_list(val, times):
   res = str(val) * times
   return res


mylist = make_list("Hello ", 5)
print(mylist)

mylist = make_list("'Ello ", 3)
print(mylist)