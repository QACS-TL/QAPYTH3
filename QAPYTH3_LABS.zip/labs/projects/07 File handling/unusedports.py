import re
file = r"C:\WINDOWS\system32\drivers\etc\services"

usedports = set()
allports = set(range(1,200))
for line in open(file, "r"):
    m = re.search(r"(\d{1,3})/(udp|tcp)", line)
    if m:
        port = int(m.groups()[0])
        if port <= 200:
            usedports.add(port)

print(usedports)
print(allports.difference(usedports))
