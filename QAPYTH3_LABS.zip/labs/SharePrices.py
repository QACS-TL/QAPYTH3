#! /usr/bin/python
# Shareprices.py for QAPYTH3.
# CBD October 2011 - delegate version.

import time
import random

SharePrices = {'Global Motors':50,
               'Big Blue Inc.':50,
               'Gates Software':50,
               'Banana Computers':50
               }

# Update stock prices with random price changes

while True:

    # TODO: update each share price (sp) to:
    # max(1.0, sp * ( 1 + ((random.random() - 0.5)/0.5) * 0.05))
    
    # TODO: print (neatly) each company and its share price
    
    # Print a blank line between
    print() 

    # pause for 2 seconds
    time.sleep(2)
            
 